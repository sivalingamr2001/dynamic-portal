import { Card, CardContent } from "@/components/ui/card"
import { Field } from "@/components/ui/field"
import { cn } from "@/lib/utils"
import { BillToDetailsPanel } from "./BillToDetailsPanel"
import { GeographicHeaderGrid } from "./GeographicHeaderGrid"
import type { useAllocationForm } from "./hooks/useAllocationForm"
import { ItemLinesTable } from "./ItemLinesTable"
import { ShipToDetailsPanel } from "./ShipToDetailsPanel"
import { Building2, Globe, ChevronDown } from "lucide-react"

type FormState = ReturnType<typeof useAllocationForm>

const TYPES = [
  { value: "customer", label: "Customer Specific", hint: "Allocate to specific customer", icon: Building2 },
  { value: "open-pool", label: "Open Pool (Any Customer)", hint: "Allocate to open pool", icon: Globe },
] as const

export function AllocationForm({ form }: { form: FormState }) {
  const {
    form: hookForm,
    lines,
    totalQty,
    addRow,
    removeRow,
    updateLine,
    submit,
    canSubmit,
    availableRegions,
    availableSubRegions,
    operatingUnits,
    itemOperatingUnits,
    ItemRrsCategories,
    ItemByCodes
  } = form

  const {
    register,
    watch,
    setValue,
    formState: { },
  } = hookForm

  // Watch critical state bindings for dynamic layout display properties
  const allocationMode = watch("allocationMode")
  const selectedRegion = watch("region")
  const selectedSubRegion = watch("subRegion")
  const hasSelectedGeo = Boolean(selectedRegion && selectedSubRegion)

  // Generate a brief textual snapshot layout preview string for collapsed view modes
  const collapsedHeaderSummary = [
    allocationMode ? `Mode: ${allocationMode}` : null,
    selectedRegion ? `Region: ${selectedRegion}` : null,
    selectedSubRegion ? `Sub-Region: ${selectedSubRegion}` : null,
  ].filter(Boolean).join(" | ")

  return (
    <form onSubmit={submit} className="space-y-6 w-full">
      <Card className="shadow-sm border-border w-full">
        <CardContent className="flex flex-col gap-6 p-4 pt-4 sm:p-5 sm:pt-5">

          {/* Collapsible HTML5 Top Header Section Container */}
          <details className="group border-b border-border pb-5 w-full" open>
            <summary className="flex cursor-pointer list-none items-center justify-between outline-none select-none">
              <div className="flex flex-col gap-0.5 sm:flex-row sm:items-center sm:gap-3">
                <h3 className="text-sm font-semibold tracking-tight text-foreground">
                  Allocation Configuration Header
                </h3>
                {/* Visual anchor preview details showing ONLY when collapsed */}
                <span className="inline-flex text-xs font-medium text-muted-foreground/80 group-open:hidden transition-all duration-200">
                  ({collapsedHeaderSummary || "No parameters configured"})
                </span>
              </div>
              <div className="flex size-7 items-center justify-center rounded-md border border-border bg-card transition-colors hover:bg-muted text-muted-foreground">
                <ChevronDown className="size-4 transition-transform duration-300 ease-in-out group-open:rotate-180" />
              </div>
            </summary>

            {/* Content Fields contained securely inside wrapper */}
            <div className="mt-5 flex flex-col gap-5 overflow-hidden w-full">

              {/* Allocation Type Interactive Switch Buttons */}
              <Field>
                <div className="grid gap-2 sm:grid-cols-2">
                  {TYPES.map(({ value, label, hint, icon: Icon }) => {
                    const isActive = allocationMode === value
                    return (
                      <button
                        key={value}
                        type="button"
                        onClick={() => setValue("allocationMode", value)}
                        className={cn(
                          "flex items-start gap-3 rounded-lg border p-3 text-left transition-all duration-150",
                          isActive
                            ? "border-primary bg-accent/40 shadow-sm"
                            : "border-border bg-card hover:bg-muted/70",
                        )}
                      >
                        <span
                          className={cn(
                            "flex size-8 items-center justify-center rounded-lg",
                            isActive ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground",
                          )}
                        >
                          <Icon className="size-4" />
                        </span>
                        <span className="flex flex-col">
                          <span className="text-sm font-medium">{label}</span>
                          <span className="text-xs text-muted-foreground">{hint}</span>
                        </span>
                      </button>
                    )
                  })}
                </div>
              </Field>

              {/* Hide the Geographic dropdowns completely when Open Pool is active */}
              {allocationMode !== "open-pool" && (
                <GeographicHeaderGrid
                  form={hookForm}
                  availableRegions={availableRegions}
                  availableSubRegions={availableSubRegions}
                  operatingUnits={operatingUnits}
                />
              )}

              {/* Customer logistics panels display ONLY if geography is picked AND mode is NOT open-pool */}
              {hasSelectedGeo && allocationMode !== "open-pool" && (
                <div className="grid gap-4 lg:grid-cols-2">
                  <BillToDetailsPanel form={hookForm} region={selectedRegion} subRegion={selectedSubRegion} />
                  <ShipToDetailsPanel form={hookForm} region={selectedRegion} subRegion={selectedSubRegion} />
                </div>
              )}

              {/* Text Comments Context Remarks Block Area */}
              <div className="grid gap-4 lg:grid-cols-2">
                <div className="space-y-1">
                  <label className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">
                    Remarks
                  </label>
                  <textarea
                    {...register("remarks")}
                    className="min-h-24 w-full rounded-lg border border-input bg-card px-3 py-2 text-sm outline-none focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/40"
                    placeholder="Add remarks for this allocation"
                  />
                </div>
              </div>

            </div>
          </details>

        </CardContent>
      </Card>

      {/* Item Rows Table Grid Interface */}
      <ItemLinesTable
        lines={lines}
        totalQty={totalQty}
        itemOperatingUnits={itemOperatingUnits}
        onAddRow={addRow}
        onRemoveRow={removeRow}
        onUpdate={updateLine}
      />

      {/* Submission Control Actions Layer Row */}
      <div className="flex justify-end">
        <button
          type="submit"
          disabled={!canSubmit}
          className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:cursor-not-allowed disabled:opacity-60 transition-opacity"
        >
          Submit Allocation
        </button>
      </div>
    </form>
  )
}
