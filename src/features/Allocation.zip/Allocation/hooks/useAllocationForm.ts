import { useEffect, useMemo, useState } from "react"
import { useForm } from "react-hook-form"
import { CATALOG } from "@/data/catalog"
import { usePortal } from "@/store/portal-store"
import {
  getAllRegionsApi,
  getOperatingUnitsApi,
  getPreparedByEmployeesApi,
  getWeeksDropdownApi,
} from "@/api/allocationApi"
import type { ItemLineDraft } from "@/data/types"
import {
  type EmployeeDto,
  type OperatingUnitDto,
  type RegionDetailsDto,
  getItemByCode,
  getItemOperatingUnits,
  getItemRrsCategory,
  type ItemOperatingUnitDto,
} from "@/api/allocationApi"

let lineId = 0
const createLine = (): ItemLineDraft => ({
  id: `line-${lineId++}`,
  organizationId: "",
  itemCode: "",
  itemName: "",
  rrsCategory: "", // Added property context tracking
  qty: 0,
  targetDate: "",
})

const getToday = () => new Date().toISOString().slice(0, 10)
const getNowIso = () => new Date().toISOString()

export function useAllocationForm() {
  const { addAllocation } = usePortal()

  // State variables configuration
  const [lines, setLines] = useState<ItemLineDraft[]>([createLine()])
  const [regionData, setRegionData] = useState<RegionDetailsDto[]>([])
  const [operatingUnits, setOperatingUnits] = useState<OperatingUnitDto[]>([])
  const [itemOperatingUnits, setItemOperatingUnits] = useState<
    ItemOperatingUnitDto[]
  >([])
  const [availableWeeks, setAvailableWeeks] = useState<string[]>([])
  const [preparedByOptions, setPreparedByOptions] = useState<EmployeeDto[]>([])

  const form = useForm<any>({
    defaultValues: {
      allocationMode: "customer",
      headerId: "",
      transactionDate: getToday(),
      customerType: "existing",
      region: "",
      subRegion: "",
      operatingUnit: "",
      weeks: "",
      preparedBy: "",
      billToId: "",
      billToCustomer: "",
      billToLocation: "",
      billToAddress: "",
      shipToId: "",
      shipToCustomer: "",
      shipToLocation: "",
      shipToAddress: "",
      remarks: "",
      expectedUse: "",
      createdBy: localStorage.getItem("currentUser") || "SYSTEM",
      createdDate: getNowIso(),
      updatedBy: localStorage.getItem("currentUser") || "SYSTEM",
      updatedDate: getNowIso(),
    },
  })

  const watchAllocationMode = form.watch("allocationMode")
  const watchRegion = form.watch("region")
  const watchBillToId = form.watch("billToId")
  const watchShipToId = form.watch("shipToId")

  // Sub-territory lookup definitions arrays computing triggers
  const availableRegions = useMemo(
    () => [...new Set(regionData.map((item) => item.region).filter(Boolean))],
    [regionData]
  )

  const availableSubRegions = useMemo(
    () => [
      ...new Set(
        regionData
          .filter((item) => !watchRegion || item.region === watchRegion)
          .map((item) => item.subRegion)
          .filter(Boolean)
      ),
    ],
    [regionData, watchRegion]
  )

  // 1. Initial Page Hydrations Calls lifecycle hooks
  useEffect(() => {
    getAllRegionsApi()
      .then((data) => setRegionData(data || []))
      .catch((error) => {
        console.error("Failed to load regions:", error)
        setRegionData([])
      })
  }, [])

  useEffect(() => {
    getOperatingUnitsApi()
      .then((data) => setOperatingUnits(data || []))
      .catch((error) => {
        console.error("Failed to load operating units:", error)
        setOperatingUnits([])
      })
  }, [])

  // 2. Fetch Item Specific Base Organizations separately
  useEffect(() => {
    getItemOperatingUnits()
      .then((data) => setItemOperatingUnits(data || []))
      .catch((error) => {
        console.error("Failed to load item operational list lines:", error)
        setItemOperatingUnits([])
      })
  }, [])

  useEffect(() => {
    getWeeksDropdownApi()
      .then((data) => setAvailableWeeks(data || []))
      .catch((error) => {
        console.error("Failed to load week options:", error)
        setAvailableWeeks([])
      })
  }, [])

  useEffect(() => {
    if (!watchRegion) {
      setPreparedByOptions([])
      return
    }

    getPreparedByEmployeesApi(watchRegion)
      .then((data) => setPreparedByOptions(data || []))
      .catch((error) => {
        console.error("Failed to load prepared-by employees:", error)
        setPreparedByOptions([])
      })
  }, [watchRegion])

  const totalQty = useMemo(
    () => lines.reduce((sum, line) => sum + (line.qty || 0), 0),
    [lines]
  )

  const filledLines = useMemo(
    () =>
      lines.filter(
        (line) =>
          line.organizationId &&
          line.itemCode &&
          line.qty > 0 &&
          line.targetDate
      ),
    [lines]
  )

  const canSubmit =
    filledLines.length > 0 &&
    !!form.getValues("headerId") &&
    !!watchRegion &&
    (watchAllocationMode === "open-pool" ||
      (!!watchBillToId && !!watchShipToId))

  const addRow = () => setLines((prev) => [...prev, createLine()])

  const removeRow = (id: string) =>
    setLines((prev) =>
      prev.length === 1 ? prev : prev.filter((line) => line.id !== id)
    )

  // 3. Line updates function executing API triggers
  const updateLine = (id: string, patch: Partial<ItemLineDraft>) => {
    setLines((prev) =>
      prev.map((line) => {
        if (line.id !== id) return line

        const next = { ...line, ...patch }

        // Local static catalog matching fallback execution loop logic
        if (patch.itemCode !== undefined) {
          const match = CATALOG.find(
            (c) => c.code.toLowerCase() === patch.itemCode!.trim().toLowerCase()
          )
          next.itemName = match ? match.name : ""
        }
        return next
      })
    )

    // Trigger async side effects when key item descriptors transform tracking
    if (patch.itemCode || patch.organizationId) {
      setLines((currentLines) =>
        currentLines.map((line) => {
          if (line.id !== id) return line

          const targetCode =
            patch.itemCode !== undefined ? patch.itemCode : line.itemCode
          const targetOrgId =
            patch.organizationId !== undefined
              ? patch.organizationId
              : line.organizationId

          if (!targetCode || !targetOrgId)
            return line

            // Background fetching processing logic
          ;(async () => {
            try {
              const itemData = await getItemByCode(targetCode.trim())
              const categoryData = await getItemRrsCategory(
                targetOrgId,
                itemData.inventoryItemId
              )

              setLines((latestLines) =>
                latestLines.map((l) =>
                  l.id === id
                    ? {
                        ...l,
                        itemName: `Resolved (${itemData.inventoryItemId})`,
                        rrsCategory: categoryData.rrsCategory,
                      }
                    : l
                )
              )
            } catch (err) {
              console.error(
                `Failed loading analytics indexes row details background context: ${id}`,
                err
              )
            }
          })()

          return line
        })
      )
    }
  }

  const submit = form.handleSubmit((values) => {
    const headerPayload = {
      headerId: values.headerId,
      transactionDate: values.transactionDate,
      customerOrItemSpecific: values.allocationMode,
      customerId: watchBillToId || watchShipToId || "",
      territoryId: values.region,
      billToCustomer: values.billToId || "",
      shipToCustomer: values.shipToId || "",
      createdBy: values.createdBy,
      createdDate: values.createdDate,
      updatedBy: values.updatedBy,
      updatedDate: values.updatedDate,
      remarks: values.remarks || values.expectedUse || "",
      operatingUnitId: values.operatingUnit,
      preparedBy: values.preparedBy,
      budgetWeek: values.weeks,
    }

    const payloadLines = filledLines.map((line) => ({
      headerId: values.headerId,
      lineId: line.id,
      organizationId: line.organizationId,
      inventoryItemId: line.itemCode,
      itemName: line.itemName,
      b3Quantity: line.qty,
      targetDate: line.targetDate,
      b3ApprovedQuantity: 0,
      approvalFlag: false,
      approvedDate: "",
      approvedBy: "",
      closureFlag: false,
    }))

    addAllocation({
      ...headerPayload,
      lines: payloadLines,
    } as any)

    setLines([createLine()])
    form.reset({
      ...values,
      headerId: "",
      billToId: "",
      billToCustomer: "",
      billToLocation: "",
      billToAddress: "",
      shipToId: "",
      shipToCustomer: "",
      shipToLocation: "",
      shipToAddress: "",
      remarks: "",
      expectedUse: "",
    })
  })

  // Expose methods matching layout requirements cleanly
  return {
    form,
    lines,
    totalQty,
    canSubmit,
    addRow,
    removeRow,
    updateLine,
    submit,
    availableRegions,
    availableSubRegions,
    operatingUnits,
    itemOperatingUnits,
    ItemRrsCategories: [], // Exposed placeholder to satisfy layout bindings
    ItemByCodes: [], // Exposed placeholder to satisfy layout bindings
    availableWeeks,
    preparedByOptions,
  }
}
