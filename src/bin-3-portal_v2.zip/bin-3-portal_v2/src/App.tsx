import { Navigate, Route, Routes } from "react-router-dom"
import { ThemeProvider } from "./store/theme-provider"
import { PortalProvider } from "@/store/portal-store"
import { AppLayout } from "@/Layout"
import { AllocationPage } from "@/pages/AllocationPage"
import { ApprovalPage } from "@/pages/ApprovalPage"
import { AmendmentPage } from "@/pages/AmendmentPage"
import { FulfillmentPage } from "@/pages/FulfillmentPage"

export default function App() {
  return (
    <ThemeProvider>
      <PortalProvider>
        <Routes>
          <Route element={<AppLayout />}>
            <Route index element={<Navigate to="/allocation" replace />} />
            <Route path="/allocation" element={<AllocationPage />} />
            <Route path="/approval" element={<ApprovalPage />} />
            <Route path="/amendment" element={<AmendmentPage />} />
            <Route path="/fulfillment" element={<FulfillmentPage />} />
            <Route path="*" element={<Navigate to="/allocation" replace />} />
          </Route>
        </Routes>
      </PortalProvider>
    </ThemeProvider>
  )
}
