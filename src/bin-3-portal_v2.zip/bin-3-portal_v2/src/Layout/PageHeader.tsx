import { CalendarDays, type LucideIcon } from "lucide-react"
import { PORTAL_META } from "./nav-config"

interface Props {
  icon: LucideIcon
  title: string
  description: string
  action?: React.ReactNode
}

export function PageHeader({ icon: Icon, title, description, action }: Props) {
  return (
    <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
      <div className="flex items-start gap-3">
        <span className="flex size-11 shrink-0 items-center justify-center rounded-xl border border-border bg-card text-primary shadow-sm">
          <Icon className="size-5" />
        </span>
        <div className="flex flex-col gap-0.5">
          <h1 className="text-xl font-bold tracking-tight text-balance">{title}</h1>
          <p className="text-sm text-muted-foreground text-pretty">{description}</p>
        </div>
      </div>
      <div className="flex items-center gap-3">
        {action}
        <span className="hidden items-center gap-1.5 rounded-lg border border-border bg-card px-3 py-2 text-xs font-medium text-muted-foreground sm:flex">
          <CalendarDays className="size-3.5" />
          {PORTAL_META.date}
        </span>
      </div>
    </div>
  )
}
