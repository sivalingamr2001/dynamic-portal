import { useMemo, useState } from "react"
import { CATALOG } from "@/data/catalog"
import { usePortal } from "@/store/portal-store"
import type { AllocationType, ItemLineDraft } from "@/data/types"

let lineId = 0
const createLine = (): ItemLineDraft => ({
  id: `line-${lineId++}`,
  itemCode: "",
  itemName: "",
  qty: 0,
  targetDate: "",
})

export function useAllocationForm() {
  const { addAllocation } = usePortal()
  const [allocationType, setAllocationType] = useState<AllocationType>("customer")
  const [customer, setCustomer] = useState("")
  const [region, setRegion] = useState("")
  const [lines, setLines] = useState<ItemLineDraft[]>([createLine()])

  const totalQty = useMemo(() => lines.reduce((sum, line) => sum + (line.qty || 0), 0), [lines])
  const filledLines = useMemo(() => lines.filter((l) => l.itemCode && l.qty > 0), [lines])

  const isOpenPool = allocationType === "open-pool"
  const canSubmit =
    filledLines.length > 0 && (isOpenPool || (customer.trim() !== "" && region !== ""))

  const addRow = () => setLines((prev) => [...prev, createLine()])

  const removeRow = (id: string) =>
    setLines((prev) => (prev.length === 1 ? prev : prev.filter((l) => l.id !== id)))

  const updateLine = (id: string, patch: Partial<ItemLineDraft>) =>
    setLines((prev) =>
      prev.map((line) => {
        if (line.id !== id) return line
        const next = { ...line, ...patch }
        if (patch.itemCode !== undefined) {
          const match = CATALOG.find(
            (c) => c.code.toLowerCase() === patch.itemCode!.trim().toLowerCase(),
          )
          next.itemName = match ? match.name : ""
        }
        return next
      }),
    )

  const submit = () => {
    if (!canSubmit) return
    addAllocation({
      customer: isOpenPool ? "Open Pool" : customer.trim(),
      region: isOpenPool ? "—" : region,
      lines: filledLines,
    })
    setLines([createLine()])
    setCustomer("")
    setRegion("")
  }

  return {
    allocationType, setAllocationType,
    customer, setCustomer,
    region, setRegion,
    lines, totalQty, filledLines,
    isOpenPool, canSubmit,
    addRow, removeRow, updateLine, submit,
  }
}
