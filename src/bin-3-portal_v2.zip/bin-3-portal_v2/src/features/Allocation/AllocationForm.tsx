import { Building2, Globe } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Input, Select } from "@/components/ui/input"
import { ItemLinesTable } from "./ItemLinesTable"
import { REGIONS } from "@/data/catalog"
import { cn } from "@/lib/utils"
import type { useAllocationForm } from "./hooks/useAllocationForm"

type Form = ReturnType<typeof useAllocationForm>

const TYPES = [
  { value: "customer", label: "Customer Specific", hint: "Allocate to specific customer", icon: Building2 },
  { value: "open-pool", label: "Open Pool (Any Customer)", hint: "Allocate to open pool", icon: Globe },
] as const

export function AllocationForm({ form }: { form: Form }) {
  return (
    <Card>
      <CardContent className="flex flex-col gap-5 p-4 pt-4 sm:p-5 sm:pt-5">
        <Field label="Allocation Type">
          <div className="grid gap-2 sm:grid-cols-2">
            {TYPES.map(({ value, label, hint, icon: Icon }) => {
              const isActive = form.allocationType === value
              return (
                <button
                  key={value}
                  type="button"
                  onClick={() => form.setAllocationType(value)}
                  className={cn(
                    "flex items-start gap-3 rounded-lg border p-3 text-left transition-colors",
                    isActive
                      ? "border-primary bg-accent"
                      : "border-border bg-card hover:bg-muted",
                  )}
                >
                  <span
                    className={cn(
                      "flex size-8 items-center justify-center rounded-lg",
                      isActive ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground",
                    )}
                  >
                    <Icon className="size-4" />
                  </span>
                  <span className="flex flex-col">
                    <span className="text-sm font-medium">{label}</span>
                    <span className="text-xs text-muted-foreground">{hint}</span>
                  </span>
                </button>
              )
            })}
          </div>
        </Field>

        {!form.isOpenPool && (
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Customer" required>
              <Input
                value={form.customer}
                onChange={(e) => form.setCustomer(e.target.value)}
                placeholder="Type customer name or code..."
              />
            </Field>
            <Field label="Region" required>
              <Select value={form.region} onChange={(e) => form.setRegion(e.target.value)}>
                <option value="">Select state / region...</option>
                {REGIONS.map((region) => (
                  <option key={region} value={region}>
                    {region}
                  </option>
                ))}
              </Select>
            </Field>
          </div>
        )}

        <ItemLinesTable
          lines={form.lines}
          totalQty={form.totalQty}
          onAddRow={form.addRow}
          onRemoveRow={form.removeRow}
          onUpdate={form.updateLine}
        />
      </CardContent>
    </Card>
  )
}

function Field({
  label,
  required,
  children,
}: {
  label: string
  required?: boolean
  children: React.ReactNode
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-xs font-medium text-muted-foreground">
        {label}
        {required && <span className="ml-0.5 text-destructive">*</span>}
      </label>
      {children}
    </div>
  )
}
