import { Plus, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { QtyInput } from "@/components/ui/qty-input"
import { formatNumber } from "@/lib/format"
import type { ItemLineDraft } from "@/data/types"

interface Props {
  lines: ItemLineDraft[]
  totalQty: number
  onAddRow: () => void
  onRemoveRow: (id: string) => void
  onUpdate: (id: string, patch: Partial<ItemLineDraft>) => void
}

export function ItemLinesTable({ lines, totalQty, onAddRow, onRemoveRow, onUpdate }: Props) {
  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold">Item Lines</h3>
        <Button variant="outline" size="sm" onClick={onAddRow}>
          <Plus /> Add Row
        </Button>
      </div>

      <div className="overflow-x-auto rounded-lg border border-border">
        <table className="w-full min-w-[640px] text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/50 text-left text-xs text-muted-foreground">
              <th className="w-10 px-3 py-2 font-medium">#</th>
              <th className="px-3 py-2 font-medium">Item Code</th>
              <th className="px-3 py-2 font-medium">Item Name</th>
              <th className="px-3 py-2 font-medium">Qty (BIN)</th>
              <th className="px-3 py-2 font-medium">Target Date</th>
              <th className="w-12 px-3 py-2" />
            </tr>
          </thead>
          <tbody>
            {lines.map((line, index) => (
              <tr key={line.id} className="border-b border-border last:border-0">
                <td className="px-3 py-2 text-muted-foreground tabular-nums">{index + 1}</td>
                <td className="px-3 py-2">
                  <Input
                    value={line.itemCode}
                    placeholder="Code / name..."
                    onChange={(e) => onUpdate(line.id, { itemCode: e.target.value })}
                    className="h-8 w-32 font-mono text-xs uppercase"
                  />
                </td>
                <td className="px-3 py-2 text-xs text-muted-foreground">
                  {line.itemName || "— select item code first"}
                </td>
                <td className="px-3 py-2">
                  <QtyInput
                    value={line.qty}
                    step={10}
                    onChange={(qty) => onUpdate(line.id, { qty })}
                  />
                </td>
                <td className="px-3 py-2">
                  <Input
                    type="date"
                    value={line.targetDate}
                    onChange={(e) => onUpdate(line.id, { targetDate: e.target.value })}
                    className="h-8 w-40"
                  />
                </td>
                <td className="px-3 py-2">
                  <Button
                    variant="ghost"
                    size="icon-sm"
                    disabled={lines.length === 1}
                    onClick={() => onRemoveRow(line.id)}
                    aria-label="Delete row"
                    className="text-muted-foreground hover:text-destructive"
                  >
                    <Trash2 />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between text-sm">
        <span className="text-muted-foreground">{lines.length} item line(s)</span>
        <span className="font-semibold">Total Qty: {formatNumber(totalQty)}</span>
      </div>
    </div>
  )
}
