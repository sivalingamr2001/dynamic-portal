import { ClipboardList, Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import { PageHeader } from "@/Layout/PageHeader"
import { StatsBar } from "@/Layout/StatsBar"
import { AllocationForm } from "@/features/Allocation/AllocationForm"
import { PortfolioWidget } from "@/features/Allocation/PortfolioWidget"
import { RecentEntriesWidget } from "@/features/Allocation/RecentEntriesWidget"
import { useAllocationForm } from "@/features/Allocation/hooks/useAllocationForm"

export function AllocationPage() {
  const form = useAllocationForm()

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        icon={ClipboardList}
        title="New BIN Allocation"
        description="Forecast commitment — allocate stock by customer or open pool"
        action={
          <Button onClick={form.submit} disabled={!form.canSubmit}>
            <Send /> Submit for Approval
          </Button>
        }
      />

      <StatsBar />

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_20rem]">
        <AllocationForm form={form} />
        <div className="flex flex-col gap-6">
          <PortfolioWidget />
          <RecentEntriesWidget />
        </div>
      </div>
    </div>
  )
}
