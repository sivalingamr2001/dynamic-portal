import { useParams } from '@tanstack/react-router';
import { useEffect } from 'react';
import { portalRegistry } from '../config/portalRegistry';
import { withSuspense } from './withSuspense';
import { RoleGuard } from './guards/RoleGuard';
import NotFound from '@/shared/components/NotFound';
import { usePortalStore } from '@/store/portalStore';

function normalizeRoutePath(path?: string) {
  return (path ?? '')
    .replace(/^\/+|\/+$/g, '');
}

function PortalRenderer() {
  const { portal, _splat } = useParams({
    strict: false,
  }) as {
    portal?: string;
    _splat?: string;
  };

  const setPortal = usePortalStore(state => state.setPortal);

  const portalModule =
    portal ? portalRegistry[portal] : undefined;

  useEffect(() => {
    if (portalModule) {
      setPortal(portalModule.name);
    }
  }, [portalModule, setPortal]);

  if (!portalModule) {
    return <NotFound />;
  }

  const routePath =
    normalizeRoutePath(_splat);

  const route = portalModule.routes.find(
    portalRoute =>
      normalizeRoutePath(portalRoute.path) === routePath,
  );

  if (!route) {
    return <NotFound />;
  }

  const Layout =
    portalModule.layout;

  const Page =
    withSuspense(route.component);

  const page = route.roles?.length ? (
    <RoleGuard roles={route.roles}>
      <Page />
    </RoleGuard>
  ) : (
    <Page />
  );

  return (
    <Layout>
      {page}
    </Layout>
  );
}

export default PortalRenderer;
