import { Loader } from "@/shared/components/Loader"
import React, { Suspense } from "react"

export const withSuspense = <P extends object>(
  Component: React.ComponentType<P>,
) => function WithSuspense(props: P) {
  return (
    <Suspense fallback={<Loader />}>
      <Component {...props} />
    </Suspense>
  )
}
