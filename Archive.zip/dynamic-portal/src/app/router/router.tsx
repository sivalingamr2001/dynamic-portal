// app/router/router.tsx

import {
  createRouter,
  createRoute,
} from '@tanstack/react-router';

import { rootRoute } from './rootRoute';
import PortalRenderer from './PortalRenderer';

const portalRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: 'portal/$portal',
  component: PortalRenderer,
});

const portalSplatRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: 'portal/$portal/$',
  component: PortalRenderer,
});

const routeTree =
  rootRoute.addChildren([
    portalRoute,
    portalSplatRoute,
  ]);

export const router =
  createRouter({
    routeTree,
  });
