export function SharedLayout({
  children,
}: React.PropsWithChildren) {
  return (
    <div className="min-h-screen bg-gray-50">
      {children}
    </div>
  );
}