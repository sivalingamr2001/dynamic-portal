import { Navigate } from '@tanstack/react-router';
import { useAuthStore } from '@/store/authStore';

export function AuthGuard({
  children,
}: React.PropsWithChildren) {
  const token = useAuthStore(state => state.token);

  if (!token) {
    return <Navigate to="/login" />;
  }

  return <>{children}</>;
}