import { useAuthStore } from '@/store/authStore';

interface Props {
  roles: string[];
  children: React.ReactNode;
}

export function RoleGuard({
  roles,
  children,
}: Props) {
  const userRoles =
    useAuthStore(state => state.roles);

  const allowed = roles.some(role =>
    userRoles.includes(role),
  );

  if (!allowed) {
    return <div>Unauthorized</div>;
  }

  return <>{children}</>;
}