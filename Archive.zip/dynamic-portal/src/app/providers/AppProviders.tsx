// app/providers/AppProviders.tsx

import { QueryProvider } from './QueryProvider';

export function AppProviders({
  children,
}: React.PropsWithChildren) {
  return (
    <QueryProvider>
      {children}
    </QueryProvider>
  );
}