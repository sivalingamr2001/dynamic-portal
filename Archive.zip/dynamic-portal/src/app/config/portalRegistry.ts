import type { PortalModule } from '@/shared/types/portal';

const modules = import.meta.glob<{ default: PortalModule }>('../../portals/*/index.ts', {
  eager: true,
});

export const portalRegistry = Object.values(modules).reduce<Record<string, PortalModule>>(
  (acc, module) => {
    const portal = module.default;

    acc[portal.name] = portal;

    return acc;
  },
  {} as Record<string, PortalModule>,
);
