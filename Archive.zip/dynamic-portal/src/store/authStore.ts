import { create } from 'zustand';

interface AuthState {
  token: string | null;
  roles: string[];
  login: (token: string) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>(set => ({
  token: null,
  roles: [],

  login: token =>
    set({
      token,
    }),

  logout: () =>
    set({
      token: null,
      roles: [],
    }),
}));
