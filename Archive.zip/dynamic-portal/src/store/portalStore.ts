import { create } from 'zustand';

interface PortalState {
  currentPortal: string | null;
  setPortal: (portal: string) => void;
}

export const usePortalStore = create<PortalState>(set => ({
  currentPortal: null,

  setPortal: portal =>
    set({
      currentPortal: portal,
    }),
}));