function Settings() {
  return (
    <section className="space-y-2">
      <h2 className="text-2xl font-semibold">Settings</h2>
      <p className="text-muted-foreground">
        Configure Green Channel portal settings.
      </p>
    </section>
  )
}

export default Settings
