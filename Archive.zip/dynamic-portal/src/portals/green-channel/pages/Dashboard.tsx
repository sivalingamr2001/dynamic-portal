function Dashboard() {
  return (
    <section className="space-y-2">
      <h2 className="text-2xl font-semibold">Dashboard</h2>
      <p className="text-muted-foreground">
        Green Channel portal dashboard rendered from the portal registry.
      </p>
    </section>
  )
}

export default Dashboard
