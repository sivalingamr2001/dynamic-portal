function Users() {
  return (
    <section className="space-y-2">
      <h2 className="text-2xl font-semibold">Users</h2>
      <p className="text-muted-foreground">
        Manage Green Channel portal users.
      </p>
    </section>
  )
}

export default Users
