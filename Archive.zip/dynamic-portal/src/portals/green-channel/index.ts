import { lazy } from 'react';
import type { PortalModule } from '@/shared/types/portal';
import GreenChannelLayout from './layouts/GreeenChannelLayout';

const greenChannelPortal: PortalModule = {
  name: 'green-channel',

  layout: GreenChannelLayout,

  routes: [
    {
      path: '',
      component: lazy(
        () => import('./GreenChannel/features/dashboard'),
      ),
    },
    {
      path: 'certifications',
      component: lazy(
        () => import('./GreenChannel/features/certification'),
      ),
    },
    {
      path: 'certifications/preview',
      component: lazy(
        () => import('./GreenChannel/features/certification/Preview'),
      ),
    },
    {
      path: 'approvals',
      component: lazy(
        () => import('./GreenChannel/features/approvals'),
      ),
      roles: ['ADMIN'],
    },
    {
      path: 'reports',
      component: lazy(
        () => import('./GreenChannel/features/reports'),
      ),
      roles: ['ADMIN'],
    },
    {
      path: 'audit',
      component: lazy(
        () => import('./GreenChannel/features/audit'),
      ),
      roles: ['ADMIN'],
    },
  ],
};

export default greenChannelPortal;
