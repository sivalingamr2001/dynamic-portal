export interface ApprovalItem {
  requestId: string;
  vendorId: string;
  vendorCode: string;
  vendorName: string;
  itemCode: string;
  itemName: string;
  category: string;
  certificationDate: string;
  certificationExpiry: string;
  remarks: string;
  status: 'pending' | 'approved' | 'rejected';
  submittedAt: string;
  submittedBy: string;
  approvedAt?: string;
  approvedBy?: string;
  approvalRemarks?: string;
  rejectionReason?: string;
  rejectionRemarks?: string;
  pendingDuration: string;
  priorRejectionCount: number;
}

export const REJECTION_REASONS = [
  'Expired certification period',
  'Missing test report',
  'Category mismatch',
  'Insufficient quality documentation',
  'Vendor not eligible for Green Channel',
  'Item specification changed',
  'Regulatory non-compliance',
  'Other',
] as const;

export type RejectionReason = (typeof REJECTION_REASONS)[number];
