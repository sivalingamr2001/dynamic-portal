import type { CertificationStatus } from './certification.types';
import type { ItemCategory } from './vendor.types';

export interface AuditLogEntry {
  id: string;
  requestId: string;
  vendorCode: string;
  vendorName: string;
  itemCode: string;
  itemName: string;
  category: ItemCategory;
  certificationDate: string;
  certificationExpiry: string;
  submittedAt: string;
  approvedBy?: string;
  status: CertificationStatus;
  remarks: string;
}

export interface AuditEvent {
  id: string;
  eventType: 'submission' | 'approval' | 'rejection' | 'bulk-approve' | 'edit' | 'deletion';
  timestamp: string;
  actor: string;
  actorRole: string;
  targetRequestId: string;
  targetItemCode: string;
  beforeState?: string;
  afterState?: string;
  remarks?: string;
  ipAddress: string;
  sessionId: string;
}

export interface ReportFilters {
  vendor: string;
  status: string;
  category: string;
  dateFrom: string;
  dateTo: string;
}
