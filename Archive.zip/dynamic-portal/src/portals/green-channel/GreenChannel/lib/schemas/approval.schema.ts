import { z } from 'zod';
import { REJECTION_REASONS } from '@green-channel/lib/types/approval.types';

export const approvalSchema = z.object({
  remarks: z.string().max(500).optional().default(''),
});

export const rejectionSchema = z.object({
  reason: z.enum(REJECTION_REASONS, { message: 'Select a rejection reason' }),
  remarks: z
    .string()
    .min(30, 'Rejection remarks must be at least 30 characters')
    .max(500, 'Remarks cannot exceed 500 characters'),
});
