import { PageWrapper } from '@green-channel/components/layout/PageWrapper';
import { ReportFilters } from './ReportFilters';
import { ReportKPIRow } from './ReportKPIRow';
import { CertificationTrendChart } from './CertificationTrendChart';
import { VendorComparisonChart } from './VendorComparisonChart';
import { AuditLogTable } from './AuditLogTable';
import { ExportControls } from './ExportControls';

export function ReportsPage() {
  return (
    <PageWrapper
      title="Reports & Analytics"
      description="Vendor-wise reports for Green Channel certified items. Filter, analyze, and export compliance data."
    >
      <ReportFilters />
      <ReportKPIRow className="mt-4" />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
        <CertificationTrendChart />
        <VendorComparisonChart />
      </div>

      <div className="mt-6 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-slate-700">Certification Audit Log</h3>
        <ExportControls />
      </div>

      <AuditLogTable className="mt-3" />
    </PageWrapper>
  );
}
