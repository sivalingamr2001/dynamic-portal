import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const DATA = [
  { vendor: 'V001', count: 45 },
  { vendor: 'V002', count: 38 },
  { vendor: 'V003', count: 62 },
  { vendor: 'V004', count: 22 },
];

export function VendorComparisonChart() {
  return (
    <div className="card p-5">
      <h3 className="text-sm font-semibold text-slate-800 mb-4">Certifications by Vendor</h3>
      <ResponsiveContainer width="100%" height={240}>
        <BarChart data={DATA} layout="vertical">
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
          <XAxis type="number" tick={{ fontSize: 11 }} />
          <YAxis dataKey="vendor" type="category" tick={{ fontSize: 11 }} width={50} />
          <Tooltip />
          <Bar dataKey="count" fill="#1d60c8" radius={[0, 4, 4, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

