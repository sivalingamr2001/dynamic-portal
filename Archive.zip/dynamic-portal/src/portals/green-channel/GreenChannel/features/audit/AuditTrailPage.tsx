import { useState } from 'react';
import { PageWrapper } from '@green-channel/components/layout/PageWrapper';
import { AuditEventRow } from './AuditEventRow';
import { AuditFilters } from './AuditFilters';
import { useAuditTrail, type AuditTrailFilters } from './hooks/useAuditTrail';
import { ShieldCheck, Download } from 'lucide-react';
import { exportToPDF } from '@green-channel/lib/utils/export';
import { TableSkeleton } from '@green-channel/components/ui/LoadingSkeleton';
import { toast } from 'sonner';

export function AuditTrailPage() {
  const [filters, setFilters] = useState<AuditTrailFilters>({
    eventType: 'all',
    actor: '',
    dateFrom: '',
    dateTo: '',
    requestId: '',
  });
  const { data: events = [], isLoading } = useAuditTrail(filters);

  return (
    <PageWrapper
      title="Audit Trail"
      description="Immutable compliance audit log. All certification actions recorded with timestamps, actors, and state changes."
      headerActions={
        <button
          type="button"
          onClick={() => {
            exportToPDF('audit-timeline', 'gcc-audit-trail');
            toast.success('PDF export started');
          }}
          className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-slate-600 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg min-h-0 min-w-0"
        >
          <Download size={15} />
          Export PDF
        </button>
      }
    >
      <div className="bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 flex items-start gap-3 mt-2">
        <ShieldCheck size={18} className="text-amber-600 mt-0.5 shrink-0" />
        <p className="text-sm text-amber-800">
          This audit trail is immutable and tamper-evident. All events are logged with cryptographic
          timestamps and cannot be edited or deleted.
        </p>
      </div>
      <AuditFilters filters={filters} onChange={setFilters} className="mt-4" />
      <div id="audit-timeline" className="card mt-4 overflow-hidden">
        {isLoading ? (
          <TableSkeleton rows={4} />
        ) : (
          <ul>
            {events.map((e) => (
              <AuditEventRow key={e.id} event={e} />
            ))}
          </ul>
        )}
      </div>
    </PageWrapper>
  );
}
