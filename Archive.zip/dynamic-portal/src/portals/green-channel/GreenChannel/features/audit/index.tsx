import { AuditTrailPage } from './AuditTrailPage';

export default AuditTrailPage;
