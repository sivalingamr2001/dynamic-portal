import { PageWrapper } from '@green-channel/components/layout/PageWrapper';
import { KPISummaryRow } from './KPISummaryRow';
import { CertificationPipelineChart } from './CertificationPipelineChart';
import { VendorCoverageDonut } from './VendorCoverageDonut';
import { RecentActivityFeed } from './RecentActivityFeed';
import { PendingApprovalAlerts } from './PendingApprovalAlerts';
import { ClipboardCheck, CheckSquare, BarChart3 } from 'lucide-react';
import { useGreenChannelNavigate } from '@green-channel/utils/navigation';

const ACTIONS = [
  {
    label: 'New Certification',
    icon: ClipboardCheck,
    to: '/certifications',
    color: 'bg-blue-600 hover:bg-blue-700',
  },
  {
    label: 'Review Approvals',
    icon: CheckSquare,
    to: '/approvals',
    color: 'bg-emerald-600 hover:bg-emerald-700',
  },
  {
    label: 'Export Report',
    icon: BarChart3,
    to: '/reports',
    color: 'bg-violet-600 hover:bg-violet-700',
  },
];

export function DashboardPage() {
  const navigate = useGreenChannelNavigate();

  function handleActionClick(path: string) {
    navigate(path);
  }

  return (
    <PageWrapper
      title="Dashboard"
      description="Operations overview — Green Channel Certification pipeline"
    >
      <KPISummaryRow />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6">
        {ACTIONS.map(action => (
          <ActionButton
            key={action.to}
            action={action}
            onClick={handleActionClick}
          />
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 mt-6">
        <div className="xl:col-span-2">
          <CertificationPipelineChart />
        </div>
        <div>
          <VendorCoverageDonut />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
        <RecentActivityFeed />
        <PendingApprovalAlerts />
      </div>
    </PageWrapper>
  );
}

interface ActionButtonProps {
  action: (typeof ACTIONS)[number];
  onClick: (path: string) => void;
}

function ActionButton({
  action,
  onClick,
}: ActionButtonProps) {
  const Icon = action.icon;

  function handleClick() {
    onClick(action.to);
  }

  return (
    <button
      type="button"
      onClick={handleClick}
      className={`${action.color} text-white flex items-center gap-3 px-4 py-3.5 rounded-xl text-sm font-semibold transition-colors shadow-sm`}
    >
      <Icon size={18} />
      {action.label}
    </button>
  );
}
