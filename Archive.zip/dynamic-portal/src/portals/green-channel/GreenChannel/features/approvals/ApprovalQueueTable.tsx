import { useMemo, useCallback } from 'react';
import { AgGridReact } from 'ag-grid-react';
import type { ColDef, GridReadyEvent, ICellRendererParams } from 'ag-grid-community';
import type { ApprovalItem } from '@green-channel/lib/types/approval.types';
import { StatusBadge } from '@green-channel/components/ui/StatusBadge';
import { CategoryBadge } from '@green-channel/components/ui/CategoryBadge';
import { SLATimer } from '@green-channel/components/ui/SLATimer';
import { formatDate } from '@green-channel/lib/utils/date';
import { cn } from '@green-channel/lib/utils/cn';
import { TableSkeleton } from '@green-channel/components/ui/LoadingSkeleton';
import { EmptyState } from '@green-channel/components/ui/EmptyState';
import '@green-channel/styles/ag-grid-theme.css';

interface ApprovalQueueTableProps {
  items: ApprovalItem[];
  isLoading: boolean;
  selectedIds: string[];
  onSelectionChange: (ids: string[]) => void;
  onApprove: (item: ApprovalItem) => void;
  onReject: (item: ApprovalItem) => void;
  className?: string;
}

export function ApprovalQueueTable({
  items,
  isLoading,
  selectedIds,
  onSelectionChange,
  onApprove,
  onReject,
  className,
}: ApprovalQueueTableProps) {
  const columnDefs = useMemo<ColDef<ApprovalItem>[]>(
    () => [
      {
        colId: 'checkbox',
        headerCheckboxSelection: true,
        checkboxSelection: true,
        pinned: 'left',
        width: 48,
        suppressHeaderMenuButton: true,
        sortable: false,
        resizable: false,
      },
      {
        field: 'requestId',
        headerName: 'Request ID',
        width: 115,
        cellClass: 'font-mono text-xs text-slate-600',
      },
      {
        field: 'vendorName',
        headerName: 'Vendor',
        width: 180,
        cellRenderer: (p: ICellRendererParams<ApprovalItem>) => (
          <div>
            <p className="text-sm font-medium text-slate-800 leading-tight">{p.data?.vendorName}</p>
            <p className="text-xs text-slate-400">{p.data?.vendorCode}</p>
          </div>
        ),
      },
      {
        field: 'itemCode',
        headerName: 'Item Code',
        width: 120,
        cellClass: 'font-mono text-xs font-medium text-slate-700',
      },
      { field: 'itemName', headerName: 'Item Name', flex: 1, minWidth: 160 },
      {
        field: 'category',
        headerName: 'Category',
        width: 120,
        cellRenderer: (p: ICellRendererParams<ApprovalItem>) =>
          p.value ? <CategoryBadge category={p.value} /> : null,
      },
      {
        field: 'certificationDate',
        headerName: 'Cert. Date',
        width: 110,
        valueFormatter: (p) => formatDate(p.value),
      },
      {
        field: 'certificationExpiry',
        headerName: 'Expiry',
        width: 110,
        valueFormatter: (p) => formatDate(p.value),
      },
      {
        field: 'remarks',
        headerName: 'Remarks',
        width: 200,
        cellRenderer: (p: ICellRendererParams<ApprovalItem>) => (
          <span title={p.value} className="text-xs text-slate-600 truncate block">
            {p.value}
          </span>
        ),
      },
      {
        field: 'submittedAt',
        headerName: 'Pending',
        width: 100,
        cellRenderer: (p: ICellRendererParams<ApprovalItem>) =>
          p.data?.status === 'pending' ? <SLATimer submittedAt={p.data.submittedAt} /> : '—',
      },
      {
        field: 'status',
        headerName: 'Status',
        width: 110,
        cellRenderer: (p: ICellRendererParams<ApprovalItem>) =>
          p.value ? <StatusBadge status={p.value} /> : null,
      },
      {
        colId: 'actions',
        headerName: 'Actions',
        pinned: 'right',
        width: 185,
        sortable: false,
        cellRenderer: (p: ICellRendererParams<ApprovalItem>) => {
          if (!p.data || p.data.status !== 'pending') return null;
          return (
            <div className="flex items-center gap-2 h-full">
              <button
                type="button"
                onClick={() => p.context.onApprove(p.data)}
                className="px-3 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg min-h-0 min-w-0"
              >
                ✓ Approve
              </button>
              <button
                type="button"
                onClick={() => p.context.onReject(p.data)}
                className="px-3 py-1.5 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg min-h-0 min-w-0"
              >
                ✕ Reject
              </button>
            </div>
          );
        },
      },
    ],
    []
  );

  const onGridReady = useCallback(
    (e: GridReadyEvent) => {
      e.api.forEachNode((node) => {
        if (node.data && selectedIds.includes(node.data.requestId)) {
          node.setSelected(true);
        }
      });
    },
    [selectedIds]
  );

  if (isLoading) return <TableSkeleton rows={5} />;
  if (items.length === 0)
    return <EmptyState title="No approvals" description="No items match your filters." />;

  return (
    <div className={cn('ag-theme-quartz ag-theme-janatics', className)} style={{ height: 480, width: '100%' }}>
      <AgGridReact<ApprovalItem>
        rowData={items}
        columnDefs={columnDefs}
        rowSelection="multiple"
        suppressRowClickSelection
        onGridReady={onGridReady}
        onSelectionChanged={(e) => {
          const ids = e.api.getSelectedRows().map((r) => r.requestId);
          onSelectionChange(ids);
        }}
        context={{ onApprove, onReject }}
        getRowId={(p) => p.data.requestId}
        animateRows
      />
    </div>
  );
}
