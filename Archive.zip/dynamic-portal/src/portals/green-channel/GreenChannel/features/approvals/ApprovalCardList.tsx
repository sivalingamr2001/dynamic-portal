import type { ApprovalItem } from '@green-channel/lib/types/approval.types';
import { StatusBadge } from '@green-channel/components/ui/StatusBadge';
import { CategoryBadge } from '@green-channel/components/ui/CategoryBadge';
import { SLATimer } from '@green-channel/components/ui/SLATimer';
import { formatDate, isSlaBreached } from '@green-channel/lib/utils/date';
import { cn } from '@green-channel/lib/utils/cn';
import { EmptyState } from '@green-channel/components/ui/EmptyState';
import { TableSkeleton } from '@green-channel/components/ui/LoadingSkeleton';
import { useState } from 'react';

interface ApprovalCardListProps {
  items: ApprovalItem[];
  isLoading: boolean;
  selectedIds: string[];
  onToggleSelect: (id: string) => void;
  onApprove: (item: ApprovalItem) => void;
  onReject: (item: ApprovalItem) => void;
  className?: string;
}

export function ApprovalCardList({
  items,
  isLoading,
  selectedIds,
  onToggleSelect,
  onApprove,
  onReject,
  className,
}: ApprovalCardListProps) {
  if (isLoading) return <TableSkeleton rows={3} />;
  if (items.length === 0)
    return <EmptyState title="No approvals" description="No items match your filters." />;

  return (
    <ul className={cn('space-y-4', className)}>
      {items.map((item) => (
        <ApprovalCard
          key={item.requestId}
          item={item}
          selected={selectedIds.includes(item.requestId)}
          onToggleSelect={() => onToggleSelect(item.requestId)}
          onApprove={() => onApprove(item)}
          onReject={() => onReject(item)}
        />
      ))}
    </ul>
  );
}

function ApprovalCard({
  item,
  selected,
  onToggleSelect,
  onApprove,
  onReject,
}: {
  item: ApprovalItem;
  selected: boolean;
  onToggleSelect: () => void;
  onApprove: () => void;
  onReject: () => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const slaBreached = item.status === 'pending' && isSlaBreached(item.submittedAt);
  const longRemarks = item.remarks.length > 80;

  return (
    <li className={cn('card p-4', slaBreached && 'ring-2 ring-amber-200')}>
      <div className="flex items-start justify-between gap-2 mb-3">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-mono text-xs font-medium text-slate-600">{item.requestId}</span>
            <StatusBadge status={item.status} />
            {item.status === 'pending' && <SLATimer submittedAt={item.submittedAt} />}
          </div>
          <p className="text-sm font-semibold text-slate-800 mt-1">{item.vendorName}</p>
          <p className="text-xs text-slate-500">{item.vendorCode}</p>
        </div>
        <input
          type="checkbox"
          checked={selected}
          onChange={onToggleSelect}
          className="w-5 h-5 rounded border-slate-300 mt-1"
          aria-label={`Select ${item.requestId}`}
        />
      </div>

      <p className="font-mono text-sm font-medium text-slate-700">{item.itemCode}</p>
      <p className="text-sm text-slate-600">{item.itemName}</p>
      <div className="flex flex-wrap gap-2 mt-2">
        <CategoryBadge category={item.category} />
        <span className="text-xs text-slate-500">
          {formatDate(item.certificationDate)} → {formatDate(item.certificationExpiry)}
        </span>
      </div>

      {item.priorRejectionCount > 0 && (
        <p className="text-xs text-amber-700 bg-amber-50 px-2 py-1 rounded mt-2 inline-block">
          ⚠ {item.priorRejectionCount} prior rejection(s)
        </p>
      )}

      <p
        className={cn('text-xs text-slate-600 mt-2', !expanded && longRemarks && 'line-clamp-2')}
        onClick={() => longRemarks && setExpanded(!expanded)}
      >
        {item.remarks}
      </p>

      {item.status === 'pending' && (
        <div className="flex gap-2 mt-4">
          <button
            type="button"
            onClick={onApprove}
            className="flex-1 py-3 bg-emerald-600 text-white text-sm font-semibold rounded-xl hover:bg-emerald-700"
          >
            ✓ Approve
          </button>
          <button
            type="button"
            onClick={onReject}
            className="flex-1 py-3 bg-red-600 text-white text-sm font-semibold rounded-xl hover:bg-red-700"
          >
            ✕ Reject
          </button>
        </div>
      )}
    </li>
  );
}

