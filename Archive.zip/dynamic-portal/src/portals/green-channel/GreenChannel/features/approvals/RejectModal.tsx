import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@green-channel/components/ui/dialog';
import { CharCountTextarea } from '@green-channel/components/ui/CharCountTextarea';
import { Button } from '@green-channel/components/ui/button';
import { rejectionSchema } from '@green-channel/lib/schemas/approval.schema';
import { REJECTION_REASONS, type ApprovalItem, type RejectionReason } from '@green-channel/lib/types/approval.types';
import { AlertTriangle } from 'lucide-react';
import type { z } from 'zod';

type RejectForm = z.infer<typeof rejectionSchema>;

interface RejectModalProps {
  item: ApprovalItem | null;
  onClose: () => void;
  onConfirm: (reason: RejectionReason, remarks: string) => Promise<void>;
}

export function RejectModal({ item, onClose, onConfirm }: RejectModalProps) {
  const {
    control,
    handleSubmit,
    watch,
    reset,
    formState: { isValid },
  } = useForm<RejectForm>({
    resolver: zodResolver(rejectionSchema),
    mode: 'onChange',
    defaultValues: { reason: undefined, remarks: '' },
  });

  const remarks = watch('remarks');

  if (!item) return null;

  const onSubmit = handleSubmit(async (data) => {
    await onConfirm(data.reason, data.remarks);
    reset();
    onClose();
  });

  return (
    <Dialog open={!!item} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-lg border-red-200">
        <DialogHeader className="bg-red-50 -mx-6 -mt-6 px-6 py-4 rounded-t-xl border-b border-red-100">
          <DialogTitle className="flex items-center gap-2 text-red-700">
            <AlertTriangle size={20} />
            Reject Certification
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3 text-sm mt-2">
          <p className="font-mono font-medium">{item.requestId}</p>
          <p>
            {item.itemCode} — {item.itemName}
          </p>
          {item.priorRejectionCount > 0 && (
            <p className="text-amber-700 bg-amber-50 px-3 py-2 rounded-lg text-xs">
              ⚠ {item.priorRejectionCount} prior rejection(s) for this item
            </p>
          )}
        </div>
        <form onSubmit={onSubmit} className="space-y-4">
          <div>
            <label className="text-sm font-medium text-slate-700 mb-1.5 block">
              Rejection Reason *
            </label>
            <Controller
              name="reason"
              control={control}
              render={({ field }) => (
                <select
                  {...field}
                  value={field.value ?? ''}
                  className="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm"
                >
                  <option value="">Select reason...</option>
                  {REJECTION_REASONS.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </select>
              )}
            />
          </div>
          <Controller
            name="remarks"
            control={control}
            render={({ field }) => (
              <CharCountTextarea
                label="Rejection Remarks *"
                value={field.value}
                onChange={field.onChange}
                minLength={30}
                maxLength={500}
                placeholder="Provide detailed context for the vendor..."
              />
            )}
          />
          <div className="flex gap-3 justify-end">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button
              type="submit"
              variant="destructive"
              disabled={!isValid || remarks.length < 30}
            >
              Confirm Rejection
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
