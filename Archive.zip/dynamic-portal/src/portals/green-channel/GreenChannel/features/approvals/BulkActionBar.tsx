import { cn } from '@green-channel/lib/utils/cn';

interface BulkActionBarProps {
  selectedCount: number;
  totalCount: number;
  onSelectAll: () => void;
  onDeselectAll: () => void;
  onBulkApprove: (remarks: string) => void;
  onBulkReject: (reason: string, remarks: string) => void;
  className?: string;
}

export function BulkActionBar({
  selectedCount,
  totalCount,
  onSelectAll,
  onDeselectAll,
  className,
}: BulkActionBarProps) {
  return (
    <div
      className={cn(
        'flex flex-wrap items-center gap-3 p-3 bg-slate-50 border border-slate-200 rounded-xl',
        selectedCount > 0 && 'ring-2 ring-blue-100',
        className
      )}
    >
      <button
        type="button"
        onClick={selectedCount === totalCount ? onDeselectAll : onSelectAll}
        className="text-sm font-medium text-blue-600 hover:text-blue-700 min-h-0 min-w-0"
      >
        {selectedCount === totalCount ? 'Deselect All' : 'Select All'}
      </button>
      <span className="text-sm text-slate-500">
        {selectedCount} of {totalCount} selected
      </span>
      {selectedCount > 0 && (
        <>
          <button
            type="button"
            className="px-4 py-2 bg-emerald-600 text-white text-sm font-semibold rounded-lg hover:bg-emerald-700 min-h-0"
          >
            Bulk Approve ({selectedCount})
          </button>
          <button
            type="button"
            className="px-4 py-2 bg-red-600 text-white text-sm font-semibold rounded-lg hover:bg-red-700 min-h-0"
          >
            Bulk Reject ({selectedCount})
          </button>
        </>
      )}
    </div>
  );
}
