import { CertificationPreviewPage } from './CertificationPreviewPage';

export default CertificationPreviewPage;
