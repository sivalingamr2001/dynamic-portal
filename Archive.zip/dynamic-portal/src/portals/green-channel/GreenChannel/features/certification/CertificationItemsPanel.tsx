import { Upload } from 'lucide-react';
import { ItemEntryForm } from './ItemEntryForm';
import type { CertificationItem } from '@green-channel/lib/types/certification.types';

interface Props {
  vendorId: string;
  existingItems: CertificationItem[];
  onAdd: (item: CertificationItem) => void;
  onBulkUploadOpen: () => void;
}

export function CertificationItemsPanel({
  vendorId,
  existingItems,
  onAdd,
  onBulkUploadOpen,
}: Props) {
  return (
    <div className="mt-6 overflow-hidden rounded-xl border border-slate-200 bg-white">
      <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
        <h3 className="text-sm font-semibold text-slate-800">Add Items for Certification</h3>
        <button
          type="button"
          onClick={onBulkUploadOpen}
          className="flex items-center gap-2 rounded-lg bg-blue-50 px-3 py-1.5 text-xs font-medium text-blue-600 hover:bg-blue-100"
        >
          <Upload size={14} />
          Bulk Upload from Excel
        </button>
      </div>
      <div className="p-5">
        <ItemEntryForm
          vendorId={vendorId}
          existingItems={existingItems}
          onAdd={onAdd}
        />
      </div>
    </div>
  );
}
