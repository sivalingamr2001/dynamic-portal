import { CertificationPage } from './CertificationPage';

export default CertificationPage;
