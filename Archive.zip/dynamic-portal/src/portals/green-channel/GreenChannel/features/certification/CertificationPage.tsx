import { useState } from 'react';
import { PageWrapper } from '@green-channel/components/layout/PageWrapper';
import { WorkflowProgress } from '@green-channel/components/ui/WorkflowProgress';
import { VendorSearchCombobox } from '@green-channel/components/shared/VendorSearchCombobox';
import { VendorDetailCard } from './VendorDetailCard';
import { CertificationStatusBar } from './CertificationStatusBar';
import { SelectedItemsTable } from './SelectedItemsTable';
import { BulkUploadModal } from '@green-channel/components/shared/BulkUploadModal';
import { useCertificationDraft } from './hooks/useCertificationDraft';
import { toast } from 'sonner';
import type { Vendor } from '@green-channel/lib/types/vendor.types';
import { useGreenChannelNavigate } from '@green-channel/utils/navigation';
import { CertificationActions } from './CertificationActions';
import { CertificationItemsPanel } from './CertificationItemsPanel';

const WORKFLOW_STEPS = ['Select Vendor', 'Add Items', 'Preview', 'Submit'];

export function CertificationPage() {
  const [bulkUploadOpen, setBulkUploadOpen] = useState(false);
  const { draft, setVendor, addItem, removeItem, clearDraft } = useCertificationDraft();
  const navigate = useGreenChannelNavigate();

  const currentStep = !draft.vendorId ? 0 : draft.items.length > 0 ? 1 : 0;
  const canPreview = draft.items.length > 0;

  function handleVendorChange(vendor: Vendor) {
    setVendor(vendor);
    toast.success(`Vendor selected: ${vendor.name}`);
  }

  function handleBulkUploadOpen() {
    setBulkUploadOpen(true);
  }

  function handleBulkUploadClose() {
    setBulkUploadOpen(false);
  }

  function handleClearDraft() {
    clearDraft();
    toast.info('Certification cleared');
  }

  function handlePreview() {
    if (draft.items.length === 0) {
      toast.error('Add at least one item before previewing');
      return;
    }
    navigate('/certifications/preview');
  }

  function handleUploadComplete(items: Parameters<typeof addItem>[0][]) {
    items.forEach(addItem);
    setBulkUploadOpen(false);
    toast.success(`${items.length} items added from upload`);
  }

  return (
    <PageWrapper
      title="Green Channel Certification"
      description="Certify vendor items to enable self-certification and skip factory inspection"
    >
      <WorkflowProgress steps={WORKFLOW_STEPS} currentStep={currentStep} />

      <section className="mt-6">
        <VendorSearchCombobox value={draft.vendorId} onChange={handleVendorChange} />
      </section>

      {draft.vendorId && (
        <>
          <VendorDetailCard vendorId={draft.vendorId} className="mt-4" />
          <CertificationStatusBar vendorId={draft.vendorId} className="mt-4" />

          <CertificationItemsPanel
            vendorId={draft.vendorId}
            existingItems={draft.items}
            onAdd={addItem}
            onBulkUploadOpen={handleBulkUploadOpen}
          />

          {draft.items.length > 0 && (
            <SelectedItemsTable items={draft.items} onRemove={removeItem} className="mt-4" />
          )}

          <CertificationActions canPreview={canPreview} onClear={handleClearDraft} onPreview={handlePreview} />
        </>
      )}

      <BulkUploadModal
        open={bulkUploadOpen}
        onClose={handleBulkUploadClose}
        vendorId={draft.vendorId}
        onUploadComplete={handleUploadComplete}
      />
    </PageWrapper>
  );
}
