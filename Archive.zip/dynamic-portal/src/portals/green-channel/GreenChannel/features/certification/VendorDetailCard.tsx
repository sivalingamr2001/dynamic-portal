import { useVendor } from '@green-channel/lib/api/vendors';
import { cn } from '@green-channel/lib/utils/cn';
import { LoadingSkeleton } from '@green-channel/components/ui/LoadingSkeleton';
import { MapPin, Mail, Phone, User } from 'lucide-react';

const TIER_STYLES = {
  gold: 'bg-amber-100 text-amber-800 border-amber-200',
  silver: 'bg-slate-100 text-slate-700 border-slate-200',
  standard: 'bg-blue-50 text-blue-700 border-blue-200',
};

export function VendorDetailCard({
  vendorId,
  className,
}: {
  vendorId: string;
  className?: string;
}) {
  const { data: vendor, isLoading } = useVendor(vendorId);

  if (isLoading) return <LoadingSkeleton className={cn('h-32 w-full', className)} />;
  if (!vendor) return null;

  return (
    <div className={cn('card p-5', className)}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-base font-semibold text-slate-800">{vendor.name}</h3>
            <span
              className={cn(
                'text-[10px] font-bold uppercase px-2 py-0.5 rounded border',
                TIER_STYLES[vendor.tier]
              )}
            >
              {vendor.tier}
            </span>
          </div>
          <p className="text-sm text-slate-500 font-mono mt-0.5">{vendor.code}</p>
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4 text-sm text-slate-600">
        <p className="flex items-center gap-2">
          <MapPin size={14} className="text-slate-400 shrink-0" />
          {vendor.city}
        </p>
        <p className="flex items-center gap-2">
          <User size={14} className="text-slate-400 shrink-0" />
          {vendor.contactPerson}
        </p>
        <p className="flex items-center gap-2">
          <Mail size={14} className="text-slate-400 shrink-0" />
          {vendor.contactEmail}
        </p>
        <p className="flex items-center gap-2">
          <Phone size={14} className="text-slate-400 shrink-0" />
          {vendor.contactPhone}
        </p>
      </div>
      <p className="text-xs text-slate-400 mt-3">GST: {vendor.gstNumber}</p>
    </div>
  );
}
