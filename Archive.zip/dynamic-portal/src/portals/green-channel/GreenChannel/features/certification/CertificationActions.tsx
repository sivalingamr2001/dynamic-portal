import { Eye } from 'lucide-react';

interface Props {
  canPreview: boolean;
  onClear: () => void;
  onPreview: () => void;
}

export function CertificationActions({
  canPreview,
  onClear,
  onPreview,
}: Props) {
  return (
    <div className="mt-6 flex flex-col gap-3 sm:flex-row">
      <button
        type="button"
        onClick={onClear}
        className="flex-1 rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-50 sm:flex-none"
      >
        Clear All
      </button>
      <button
        type="button"
        onClick={onPreview}
        disabled={!canPreview}
        className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-blue-600 px-6 py-2.5 text-sm font-semibold text-white hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-50 sm:flex-none"
      >
        <Eye size={16} />
        Preview Submission
      </button>
    </div>
  );
}
