interface Props {
  value: string;
  error?: string;
}

export function ItemNameField({
  value,
  error,
}: Props) {
  return (
    <div>
      <label className="mb-1.5 block text-sm font-medium text-slate-700">Item Name</label>
      <input
        value={value}
        readOnly
        className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-600"
      />
      {error && <p className="mt-1 text-xs text-red-600">{error}</p>}
    </div>
  );
}
