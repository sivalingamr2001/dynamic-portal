import {
  useMemo,
  useState,
} from 'react';
import { Plus } from 'lucide-react';
import { CharCountTextarea } from '@green-channel/components/ui/CharCountTextarea';
import { DatePickerField } from '@green-channel/components/shared/DatePickerField';
import { ItemCodeCombobox } from '@green-channel/components/shared/ItemCodeCombobox';
import { itemEntrySchema } from '@green-channel/lib/schemas/certification.schema';
import type { CertificationItem } from '@green-channel/lib/types/certification.types';
import type { VendorItem } from '@green-channel/lib/types/vendor.types';
import { ItemNameField } from './ItemNameField';

interface Props {
  vendorId: string;
  existingItems: CertificationItem[];
  onAdd: (item: CertificationItem) => void;
}

const EMPTY_FORM = {
  itemCode: '',
  itemName: '',
  category: '',
  certificationDate: '',
  remarks: '',
};

export function ItemEntryForm({
  vendorId,
  existingItems,
  onAdd,
}: Props) {
  const [form, setForm] = useState(EMPTY_FORM);

  const existingCodes = useMemo(
    () => existingItems.map(item => item.itemCode),
    [existingItems],
  );
  const parsed = itemEntrySchema.safeParse(form);
  const errors = parsed.success ? {} : parsed.error.flatten().fieldErrors;

  function handleItemSelect(item: VendorItem) {
    setForm(value => ({
      ...value,
      itemCode: item.code,
      itemName: item.name,
      category: item.category,
    }));
  }

  function handleDateChange(certificationDate: string) {
    setForm(value => ({ ...value, certificationDate }));
  }

  function handleRemarksChange(remarks: string) {
    setForm(value => ({ ...value, remarks }));
  }

  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!parsed.success) {
      return;
    }

    onAdd({
      ...parsed.data,
      category: parsed.data.category as CertificationItem['category'],
    });
    setForm(EMPTY_FORM);
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <ItemCodeCombobox
          vendorId={vendorId}
          value={form.itemCode}
          onSelect={handleItemSelect}
          existingCodes={existingCodes}
        />
        <ItemNameField value={form.itemName} error={errors.itemName?.[0]} />
        <DatePickerField
          label="Certification Date"
          value={form.certificationDate}
          onChange={handleDateChange}
          error={errors.certificationDate?.[0]}
        />
      </div>
      <CharCountTextarea
        label="Remarks"
        value={form.remarks}
        onChange={handleRemarksChange}
        minLength={20}
        maxLength={500}
        placeholder="Describe certification basis, test standards, and quality evidence..."
        error={errors.remarks?.[0]}
      />
      <button type="submit" disabled={!parsed.success} className="flex items-center gap-2 rounded-xl bg-blue-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-50">
        <Plus size={16} />
        Add Item
      </button>
    </form>
  );
}
