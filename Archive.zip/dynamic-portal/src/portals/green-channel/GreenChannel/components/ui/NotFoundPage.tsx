import { Home } from 'lucide-react';
import { GreenChannelLink } from '@green-channel/utils/navigation';

export function NotFoundPage() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50 px-4">
      <h1 className="text-6xl font-bold text-blue-600">404</h1>
      <p className="text-lg text-slate-600 mt-2">Page not found</p>
      <GreenChannelLink
        to="/dashboard"
        className="mt-6 flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-semibold hover:bg-blue-700"
      >
        <Home size={16} />
        Back to Dashboard
      </GreenChannelLink>
    </div>
  );
}
