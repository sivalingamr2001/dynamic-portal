import { cn } from '@green-channel/lib/utils/cn';

interface CharCountTextareaProps {
  value: string;
  onChange: (value: string) => void;
  minLength?: number;
  maxLength?: number;
  placeholder?: string;
  label?: string;
  error?: string;
  className?: string;
}

export function CharCountTextarea({
  value,
  onChange,
  minLength = 0,
  maxLength = 500,
  placeholder,
  label,
  error,
  className,
}: CharCountTextareaProps) {
  const count = value.length;
  const isBelowMin = minLength > 0 && count < minLength;
  const isNearMax = count > maxLength * 0.9;

  return (
    <div className={cn('flex flex-col gap-1.5', className)}>
      {label && <label className="text-sm font-medium text-slate-700">{label}</label>}
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        maxLength={maxLength}
        placeholder={placeholder}
        rows={3}
        className={cn(
          'w-full px-3 py-2.5 text-sm rounded-lg border resize-none min-h-[88px] min-w-0',
          'focus:outline-none focus:ring-2 focus:ring-offset-0 transition-colors',
          isBelowMin
            ? 'border-red-300 focus:ring-red-200 focus:border-red-400'
            : 'border-slate-300 focus:ring-blue-200 focus:border-blue-400'
        )}
      />
      <div className="flex items-center justify-between text-xs">
        {isBelowMin ? (
          <span className="text-red-600">
            Need {minLength - count} more characters (minimum {minLength})
          </span>
        ) : error ? (
          <span className="text-red-600">{error}</span>
        ) : (
          <span className="text-slate-400">&nbsp;</span>
        )}
        <span
          className={cn(
            'tabular-nums',
            isBelowMin ? 'text-red-500' : isNearMax ? 'text-amber-500' : 'text-slate-400'
          )}
        >
          {count} / {maxLength}
        </span>
      </div>
    </div>
  );
}
