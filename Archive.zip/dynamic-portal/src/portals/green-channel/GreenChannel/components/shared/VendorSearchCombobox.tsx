import { useState, useEffect, useRef } from 'react';
import { useDebouncedValue } from '@green-channel/lib/hooks/useDebouncedValue';
import { useVendors } from '@green-channel/lib/api/vendors';
import { useMediaQuery } from '@green-channel/lib/hooks/useMediaQuery';
import type { Vendor } from '@green-channel/lib/types/vendor.types';
import { Search, ChevronDown, Clock } from 'lucide-react';
import { cn } from '@green-channel/lib/utils/cn';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@green-channel/components/ui/dialog';

const RECENT_KEY = 'janatics-recent-vendors';

function getRecentVendors(): string[] {
  try {
    return JSON.parse(localStorage.getItem(RECENT_KEY) ?? '[]');
  } catch {
    return [];
  }
}

function saveRecentVendor(id: string) {
  const recent = getRecentVendors().filter((r) => r !== id);
  recent.unshift(id);
  localStorage.setItem(RECENT_KEY, JSON.stringify(recent.slice(0, 5)));
}

const TIER_COLORS = {
  gold: 'bg-amber-100 text-amber-700',
  silver: 'bg-slate-200 text-slate-700',
  standard: 'bg-blue-50 text-blue-700',
};

export function VendorSearchCombobox({
  value,
  onChange,
}: {
  value: string;
  onChange: (vendor: Vendor) => void;
}) {
  const [search, setSearch] = useState('');
  const [open, setOpen] = useState(false);
  const [sheetOpen, setSheetOpen] = useState(false);
  const debounced = useDebouncedValue(search, 300);
  const { data: vendors = [] } = useVendors(debounced || undefined);
  const isMobile = useMediaQuery('(max-width: 768px)');
  const containerRef = useRef<HTMLDivElement>(null);
  const selected = vendors.find((v) => v.id === value);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleSelect = (vendor: Vendor) => {
    saveRecentVendor(vendor.id);
    onChange(vendor);
    setOpen(false);
    setSheetOpen(false);
    setSearch('');
  };

  const VendorList = ({ list }: { list: Vendor[] }) => (
    <ul className="max-h-64 overflow-y-auto">
      {list.length === 0 ? (
        <li className="px-4 py-6 text-sm text-slate-500 text-center">No vendors found</li>
      ) : (
        list.map((v) => (
          <li key={v.id}>
            <button
              type="button"
              onClick={() => handleSelect(v)}
              className="w-full px-4 py-3 text-left hover:bg-slate-50 flex items-start gap-3"
            >
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-slate-800">{v.name}</p>
                <p className="text-xs text-slate-500">
                  {v.code} · {v.city}
                </p>
              </div>
              <span
                className={cn(
                  'text-[10px] font-semibold uppercase px-1.5 py-0.5 rounded',
                  TIER_COLORS[v.tier]
                )}
              >
                {v.tier}
              </span>
            </button>
          </li>
        ))
      )}
    </ul>
  );

  if (isMobile) {
    return (
      <>
        <button
          type="button"
          onClick={() => setSheetOpen(true)}
          className="w-full flex items-center justify-between px-4 py-3 bg-white border border-slate-300 rounded-xl text-sm"
        >
          <span className={selected ? 'text-slate-800 font-medium' : 'text-slate-400'}>
            {selected ? `${selected.code} — ${selected.name}` : 'Search vendor by code or name...'}
          </span>
          <ChevronDown size={16} className="text-slate-400" />
        </button>
        <Dialog open={sheetOpen} onOpenChange={setSheetOpen}>
          <DialogContent className="fixed bottom-0 top-auto left-0 right-0 translate-x-0 translate-y-0 max-w-full rounded-t-2xl rounded-b-none max-h-[80vh]">
            <DialogHeader>
              <DialogTitle>Select Vendor</DialogTitle>
            </DialogHeader>
            <div className="relative mb-3">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search vendors..."
                className="w-full pl-9 pr-4 py-3 border border-slate-300 rounded-lg text-sm"
                autoFocus
              />
            </div>
            <VendorList list={vendors} />
          </DialogContent>
        </Dialog>
      </>
    );
  }

  return (
    <div ref={containerRef} className="relative">
      <label className="text-sm font-medium text-slate-700 mb-1.5 block">Vendor</label>
      <div className="relative">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          value={open ? search : selected ? `${selected.code} — ${selected.name}` : search}
          onChange={(e) => {
            setSearch(e.target.value);
            setOpen(true);
          }}
          onFocus={() => setOpen(true)}
          placeholder="Search vendor by code, name, or city..."
          className="w-full pl-9 pr-4 py-3 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-200"
        />
      </div>
      {open && (
        <div className="absolute z-50 w-full mt-1 bg-white border border-slate-200 rounded-xl shadow-lg overflow-hidden">
          {getRecentVendors().length > 0 && !search && (
            <div className="border-b border-slate-100">
              <p className="px-4 py-2 text-xs font-medium text-slate-400 flex items-center gap-1">
                <Clock size={12} /> Recent
              </p>
              <VendorList
                list={getRecentVendors()
                  .map((id) => vendors.find((v) => v.id === id))
                  .filter(Boolean) as Vendor[]}
              />
            </div>
          )}
          <VendorList list={vendors} />
        </div>
      )}
    </div>
  );
}
