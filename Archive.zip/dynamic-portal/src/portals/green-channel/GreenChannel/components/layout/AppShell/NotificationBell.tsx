import { Bell } from 'lucide-react';

interface Props {
  count: number;
}

export function NotificationBell({
  count,
}: Props) {
  const label = count > 0
    ? `Notifications, ${count} pending`
    : 'Notifications';

  return (
    <button
      type="button"
      className="relative rounded-md p-2 text-slate-500 hover:bg-slate-100"
      aria-label={label}
    >
      <Bell size={20} />
      {count > 0 && (
        <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-orange-500" />
      )}
    </button>
  );
}
