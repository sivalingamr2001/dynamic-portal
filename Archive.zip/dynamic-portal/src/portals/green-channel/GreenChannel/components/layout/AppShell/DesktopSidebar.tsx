import {
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { cn } from '@green-channel/lib/utils/cn';
import { GreenChannelLink } from '@green-channel/utils/navigation';
import { UserProfile } from './UserProfile';
import type { NavProps } from './types';

interface Props extends NavProps {
  isOpen: boolean;
  onToggle: () => void;
}

export function DesktopSidebar({
  items,
  pathname,
  pendingCount,
  isOpen,
  onToggle,
}: Props) {
  return (
    <aside className={cn(
      'hidden flex-col border-r border-slate-200 bg-white lg:flex',
      'transition-all duration-300 ease-in-out',
      isOpen ? 'w-60' : 'w-16',
    )}>
      <div className="flex items-center justify-between border-b border-slate-100 px-4 py-5">
        {isOpen && <Brand />}
        <button type="button" onClick={onToggle} className="ml-auto rounded-md p-1.5 text-slate-500 hover:bg-slate-100">
          {isOpen ? <ChevronLeft size={16} /> : <ChevronRight size={16} />}
        </button>
      </div>
      <nav className="flex-1 space-y-0.5 overflow-y-auto px-2 py-4">
        {items.map(item => (
          <DesktopNavItem key={item.path} item={item} pathname={pathname} pendingCount={pendingCount} isOpen={isOpen} />
        ))}
      </nav>
      {isOpen && (
        <div className="border-t border-slate-100 px-3 py-4">
          <UserProfile />
        </div>
      )}
    </aside>
  );
}

function Brand() {
  return (
    <div>
      <span className="text-sm font-bold tracking-tight text-blue-700">JANATICS</span>
      <p className="mt-0.5 text-[10px] uppercase tracking-widest text-slate-400">Green Channel</p>
    </div>
  );
}

function DesktopNavItem({ item, pathname, pendingCount, isOpen }: {
  item: NavProps['items'][number];
  pathname: string;
  pendingCount: number;
  isOpen: boolean;
}) {
  const isActive = item.path ? pathname.endsWith(item.path) : pathname.endsWith('green-channel');
  const Icon = item.icon;

  return (
    <GreenChannelLink to={item.path} className={cn(
      'group relative flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium',
      isActive ? 'bg-blue-50 text-blue-700' : 'text-slate-600 hover:bg-slate-50',
    )}>
      <Icon size={18} className={isActive ? 'text-blue-600' : 'text-slate-400'} />
      {isOpen && <span className="flex-1">{item.label}</span>}
      {item.hasBadge && pendingCount > 0 && isOpen && <Badge count={pendingCount} />}
      {item.hasBadge && pendingCount > 0 && !isOpen && <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-orange-500" />}
    </GreenChannelLink>
  );
}

function Badge({ count }: { count: number }) {
  return (
    <span className="min-w-[18px] rounded-full bg-orange-500 px-1.5 py-0.5 text-center text-[10px] font-bold text-white">
      {count > 99 ? '99+' : count}
    </span>
  );
}
