import { X } from 'lucide-react';
import { cn } from '@green-channel/lib/utils/cn';
import { GreenChannelLink } from '@green-channel/utils/navigation';
import { UserProfile } from './UserProfile';
import type { NavProps } from './types';

interface Props extends NavProps {
  isOpen: boolean;
  onClose: () => void;
}

export function MobileMenu({
  items,
  pathname,
  pendingCount,
  isOpen,
  onClose,
}: Props) {
  if (!isOpen) {
    return null;
  }

  return (
    <div className="fixed inset-0 z-50 lg:hidden">
      <button type="button" aria-label="Close menu overlay" className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <aside className="absolute bottom-0 left-0 top-0 flex w-72 flex-col bg-white shadow-2xl">
        <Header onClose={onClose} />
        <nav className="flex-1 space-y-0.5 px-3 py-4">
          {items.map(item => (
            <GreenChannelLink
              key={item.path}
              to={item.path}
              onClick={onClose}
              className={cn(
                'flex items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium',
                pathname.endsWith(item.path) ? 'bg-blue-50 text-blue-700' : 'text-slate-600',
              )}
            >
              <item.icon size={20} className="text-slate-400" />
              <span className="flex-1">{item.label}</span>
              {item.hasBadge && pendingCount > 0 && <Badge count={pendingCount} />}
            </GreenChannelLink>
          ))}
        </nav>
        <div className="border-t border-slate-100 px-4 py-4">
          <UserProfile />
        </div>
      </aside>
    </div>
  );
}

function Header({ onClose }: { onClose: () => void }) {
  return (
    <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
      <div>
        <span className="text-sm font-bold text-blue-700">JANATICS</span>
        <p className="text-[10px] uppercase tracking-widest text-slate-400">Green Channel Initiative</p>
      </div>
      <button type="button" onClick={onClose} className="rounded-md p-1.5 hover:bg-slate-100">
        <X size={18} className="text-slate-500" />
      </button>
    </div>
  );
}

function Badge({ count }: { count: number }) {
  return (
    <span className="rounded-full bg-orange-500 px-1.5 py-0.5 text-[10px] font-bold text-white">
      {count}
    </span>
  );
}
