import type { LucideIcon } from 'lucide-react';

export interface NavItem {
  path: string;
  label: string;
  icon: LucideIcon;
  hasBadge?: boolean;
}

export interface ShellProps {
  children: React.ReactNode;
}

export interface NavProps {
  items: NavItem[];
  pathname: string;
  pendingCount: number;
}
