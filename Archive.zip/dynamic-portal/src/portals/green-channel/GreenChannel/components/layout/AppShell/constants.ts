import {
  BarChart3,
  CheckSquare,
  ClipboardCheck,
  LayoutDashboard,
  ScrollText,
} from 'lucide-react';
import type { NavItem } from './types';

export const NAV_ITEMS: NavItem[] = [
  { path: '', label: 'Dashboard', icon: LayoutDashboard },
  { path: 'certifications', label: 'Certifications', icon: ClipboardCheck },
  { path: 'approvals', label: 'Approvals', icon: CheckSquare, hasBadge: true },
  { path: 'reports', label: 'Reports', icon: BarChart3 },
  { path: 'audit', label: 'Audit Trail', icon: ScrollText },
];

export const BREADCRUMB_LABELS: Record<string, string> = {
  'green-channel': 'Green Channel',
  certifications: 'Certifications',
  preview: 'Preview',
  approvals: 'Approvals',
  reports: 'Reports',
  audit: 'Audit Trail',
};
