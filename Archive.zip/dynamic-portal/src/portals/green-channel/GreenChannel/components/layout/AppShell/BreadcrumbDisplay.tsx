import { BREADCRUMB_LABELS } from './constants';

interface Props {
  pathname: string;
}

function getSegments(pathname: string) {
  return pathname
    .split('/')
    .filter(Boolean)
    .filter(segment => segment !== 'portal');
}

export function BreadcrumbDisplay({
  pathname,
}: Props) {
  const segments = getSegments(pathname);

  return (
    <nav className="text-sm text-slate-500">
      <span className="text-slate-400">Home</span>
      {segments.map(segment => (
        <span key={segment}>
          <span className="mx-1.5 text-slate-300">/</span>
          <span className="font-medium text-slate-700">
            {BREADCRUMB_LABELS[segment] ?? segment}
          </span>
        </span>
      ))}
    </nav>
  );
}
