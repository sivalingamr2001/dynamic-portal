interface Props {
  isCompact?: boolean;
}

export function UserProfile({
  isCompact = false,
}: Props) {
  if (isCompact) {
    return (
      <div className="h-8 w-8 rounded-full bg-blue-600 flex items-center justify-center text-white text-xs font-bold">
        SK
      </div>
    );
  }

  return (
    <div className="flex items-center gap-3">
      <div className="h-9 w-9 rounded-full bg-blue-600 flex items-center justify-center text-white text-xs font-bold">
        SK
      </div>
      <div>
        <p className="text-sm font-semibold text-slate-800">Shiva Kumar</p>
        <p className="text-xs text-slate-500">Admin · Compliance Officer</p>
      </div>
    </div>
  );
}
