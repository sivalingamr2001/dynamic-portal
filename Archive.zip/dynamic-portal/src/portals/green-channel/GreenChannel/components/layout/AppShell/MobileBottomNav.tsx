import { cn } from '@green-channel/lib/utils/cn';
import { GreenChannelLink } from '@green-channel/utils/navigation';
import type { NavProps } from './types';

export function MobileBottomNav({
  items,
  pathname,
  pendingCount,
}: NavProps) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 flex border-t border-slate-200 bg-white lg:hidden">
      {items.map(item => (
        <MobileNavItem
          key={item.path}
          item={item}
          pathname={pathname}
          pendingCount={pendingCount}
        />
      ))}
    </nav>
  );
}

function MobileNavItem({
  item,
  pathname,
  pendingCount,
}: {
  item: NavProps['items'][number];
  pathname: string;
  pendingCount: number;
}) {
  const isActive = item.path ? pathname.endsWith(item.path) : pathname.endsWith('green-channel');
  const Icon = item.icon;

  return (
    <GreenChannelLink
      to={item.path}
      className={cn(
        'relative flex flex-1 flex-col items-center justify-center gap-0.5 py-2.5 text-[10px] font-medium',
        isActive ? 'text-blue-600' : 'text-slate-500',
      )}
    >
      <span className="relative">
        <Icon size={20} />
        {item.hasBadge && pendingCount > 0 && <Badge count={pendingCount} />}
      </span>
      <span>{item.label.split(' ')[0]}</span>
    </GreenChannelLink>
  );
}

function Badge({ count }: { count: number }) {
  return (
    <span className="absolute -right-1.5 -top-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-orange-500 text-[8px] font-bold text-white">
      {count > 9 ? '9+' : count}
    </span>
  );
}
