import { useRouterState } from '@tanstack/react-router';
import { Menu } from 'lucide-react';
import { useState } from 'react';
import { useApprovalCount } from '@green-channel/features/approvals/hooks/useApprovals';
import { BreadcrumbDisplay } from './BreadcrumbDisplay';
import { DesktopSidebar } from './DesktopSidebar';
import { MobileBottomNav } from './MobileBottomNav';
import { MobileMenu } from './MobileMenu';
import { NAV_ITEMS } from './constants';
import { NotificationBell } from './NotificationBell';
import { UserProfile } from './UserProfile';
import type { ShellProps } from './types';

export function AppShell({
  children,
}: ShellProps) {
  const [isSidebarOpen, setSidebarOpen] = useState(true);
  const [isMobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { data: pendingCount = 0 } = useApprovalCount();
  const pathname = useRouterState({ select: state => state.location.pathname });

  function handleToggleSidebar() {
    setSidebarOpen(value => !value);
  }

  function handleOpenMobileMenu() {
    setMobileMenuOpen(true);
  }

  function handleCloseMobileMenu() {
    setMobileMenuOpen(false);
  }

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      <DesktopSidebar items={NAV_ITEMS} pathname={pathname} pendingCount={pendingCount} isOpen={isSidebarOpen} onToggle={handleToggleSidebar} />
      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
        <header className="flex shrink-0 items-center justify-between border-b border-slate-200 bg-white px-4 py-3 lg:px-6">
          <div className="flex items-center gap-3">
            <button type="button" className="rounded-md p-2 text-slate-500 hover:bg-slate-100 lg:hidden" onClick={handleOpenMobileMenu}>
              <Menu size={20} />
            </button>
            <div className="hidden lg:block">
              <BreadcrumbDisplay pathname={pathname} />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <NotificationBell count={pendingCount} />
            <div className="hidden items-center gap-2 border-l border-slate-200 pl-2 sm:flex">
              <UserProfile isCompact />
              <span className="hidden text-sm font-medium text-slate-700 md:block">Shiva Kumar</span>
            </div>
          </div>
        </header>
        <main className="flex-1 overflow-y-auto pb-16 lg:pb-0">{children}</main>
      </div>
      <MobileMenu items={NAV_ITEMS} pathname={pathname} pendingCount={pendingCount} isOpen={isMobileMenuOpen} onClose={handleCloseMobileMenu} />
      <MobileBottomNav items={NAV_ITEMS} pathname={pathname} pendingCount={pendingCount} />
    </div>
  );
}
