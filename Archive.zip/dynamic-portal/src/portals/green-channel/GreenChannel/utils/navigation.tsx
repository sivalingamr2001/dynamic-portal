import {
  Link,
  useNavigate,
} from '@tanstack/react-router';
import type { ComponentProps } from 'react';

const PORTAL_BASE_PATH = '/portal/green-channel';

export function getGreenChannelPath(path = '') {
  const cleanPath = path.replace(/^\/+/, '');

  if (!cleanPath || cleanPath === 'dashboard') {
    return PORTAL_BASE_PATH;
  }

  return `${PORTAL_BASE_PATH}/${cleanPath}`;
}

export function useGreenChannelNavigate() {
  const navigate = useNavigate();

  function handleNavigate(path: string) {
    navigate({
      to: getGreenChannelPath(path),
    });
  }

  return handleNavigate;
}

interface Props extends Omit<ComponentProps<typeof Link>, 'to'> {
  to: string;
}

export function GreenChannelLink({
  to,
  ...props
}: Props) {
  return (
    <Link
      {...props}
      to={getGreenChannelPath(to)}
    />
  );
}
