import { AppShell } from '../GreenChannel/components/layout/AppShell';

function GreeenChannelLayout({
  children,
}: React.PropsWithChildren) {
  return <AppShell>{children}</AppShell>
}

export default GreeenChannelLayout
