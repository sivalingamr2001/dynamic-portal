import ReactDOM from 'react-dom/client';
import { RouterProvider } from '@tanstack/react-router';
import './index.css'

import { router } from './app/router/router';
import { AppProviders } from './app/providers/AppProviders';
import { ThemeProvider } from './app/providers/theme-provider';

ReactDOM.createRoot(
  document.getElementById('root')!,
).render(
  <AppProviders>
    <ThemeProvider>
    <RouterProvider router={router} />
    </ThemeProvider>
  </AppProviders>,
);