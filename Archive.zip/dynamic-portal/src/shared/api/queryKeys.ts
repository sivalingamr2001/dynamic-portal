export const queryKeys = {
  employees: ['employees'] as const,
  reports: ['reports'] as const,
  users: ['users'] as const,
};