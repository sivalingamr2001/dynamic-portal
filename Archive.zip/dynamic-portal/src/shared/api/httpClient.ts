import axios from 'axios';
import { env } from '@/app/config/env';
import { useAuthStore } from '@/store/authStore';

export const httpClient = axios.create({
  baseURL: env.apiUrl,
  timeout: 30000,
});

httpClient.interceptors.request.use(config => {
  const token = useAuthStore.getState().token;

  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }

  return config;
});

httpClient.interceptors.response.use(
  response => response,
  error => {
    if (error.response?.status === 401) {
      useAuthStore.getState().logout();
    }

    return Promise.reject(error);
  },
);
