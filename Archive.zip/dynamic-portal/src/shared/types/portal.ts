export interface PortalRouteDefinition {
  path: string;
  component: React.ComponentType;
  roles?: string[];
  permissions?: string[];
}

export interface PortalModule {
  name: string;
  layout: React.ComponentType<{ children: React.ReactNode }>;
  routes: PortalRouteDefinition[];
}