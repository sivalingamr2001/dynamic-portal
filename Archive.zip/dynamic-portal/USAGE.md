# Dynamic Portal Usage

This app renders portals dynamically from files under `src/portals`.

## Run The App

```bash
npm run dev
```

Open a portal with this URL format:

```text
/portal/:portalName
/portal/:portalName/:routePath
```

Current examples:

```text
/portal/green-channel
/portal/green-channel/users
/portal/green-channel/settings
```

## How It Works

`src/app/config/portalRegistry.ts` automatically imports every portal module that matches:

```text
src/portals/*/index.ts
```

Each module is stored by its `name`.

`src/app/router/router.tsx` defines the dynamic route shell:

```text
/portal/$portal
/portal/$portal/$
```

`src/app/router/PortalRenderer.tsx` reads the URL params, finds the portal module, finds the matching route inside that module, and renders the route component inside the portal layout.

## Portal Module Contract

Each portal must default export a `PortalModule`:

```ts
export interface PortalModule {
  name: string
  layout: React.ComponentType<{ children: React.ReactNode }>
  routes: PortalRouteDefinition[]
}
```

Each route uses this shape:

```ts
export interface PortalRouteDefinition {
  path: string
  component: React.ComponentType
  roles?: string[]
  permissions?: string[]
}
```

Use an empty string path for the portal dashboard route:

```ts
{
  path: '',
  component: lazy(() => import('./pages/Dashboard')),
}
```

## Add A New Portal

Create this folder structure:

```text
src/portals/my-portal/
  index.ts
  layouts/MyPortalLayout.tsx
  pages/Dashboard.tsx
```

Example `index.ts`:

```ts
import { lazy } from 'react'
import type { PortalModule } from '@/shared/types/portal'
import MyPortalLayout from './layouts/MyPortalLayout'

const myPortal: PortalModule = {
  name: 'my-portal',
  layout: MyPortalLayout,
  routes: [
    {
      path: '',
      component: lazy(() => import('./pages/Dashboard')),
    },
  ],
}

export default myPortal
```

Now open:

```text
/portal/my-portal
```

No router changes are needed as long as the portal folder has an `index.ts` default export.

## Add A Route To A Portal

Add a page file:

```text
src/portals/green-channel/pages/Reports.tsx
```

Then add it to that portal's `routes` array:

```ts
{
  path: 'reports',
  component: lazy(() => import('./pages/Reports')),
}
```

Open it at:

```text
/portal/green-channel/reports
```

## Protected Routes

Routes can declare roles:

```ts
{
  path: 'users',
  component: lazy(() => import('./pages/Users')),
  roles: ['ADMIN'],
}
```

`PortalRenderer` wraps those pages with `RoleGuard`.

## Build

```bash
npm run build
```

Use this before shipping changes. It runs TypeScript and the Vite production build.
